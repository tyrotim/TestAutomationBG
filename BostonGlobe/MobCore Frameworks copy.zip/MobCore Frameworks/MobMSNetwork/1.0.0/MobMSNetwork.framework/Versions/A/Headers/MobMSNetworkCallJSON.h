//
//  MobMSNetworkCallJSON.h
//  MobMSNetwork
//
//  Created by Nidal Fakhouri on 11/17/12.
//  Copyright (c) 2012 mobiquity. All rights reserved.
//

#import "MobMSNetworkCall.h"

/***/
@interface MobMSNetworkCallJSON : MobMSNetworkCall

/***/
@property (nonatomic, strong) id responseJSON;

@end
