//
//  MobMSNetworkCallImage.h
//  MobMSNetwork
//
//  Created by Nidal Fakhouri on 11/17/12.
//  Copyright (c) 2012 mobiquity. All rights reserved.
//

#import "MobMSNetworkCall.h"

/***/
@interface MobMSNetworkCallImage : MobMSNetworkCall

/***/
@property (nonatomic, strong) UIImage *responseImage;

@end
